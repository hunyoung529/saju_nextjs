import React from 'react'
import Community from '../../comp/Community'

function page() {
  return (
  
      <Community/>

  )
}

export default page