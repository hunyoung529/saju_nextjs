import React from "react";
import Myfortune from "../../comp/Myfortune";

function page() {
  return (
    <div>
      <Myfortune />
    </div>
  );
}

export default page;
